﻿# Partenariat Simplon
## Une Simple Extention WordPress

### Description :

ce package ajoute un commentaire 

### Installation :

Aller dans la section extension , charger le fichier zip contenant le fichier php et read me. Activer l'extension .

### Utilisation :

Au lieu de la publication inserer le short code suivant : [simplon]


#### Shortcodes :
[simplon]
